@echo off
chcp 65001 >nul
setlocal
REM ============================================================
REM   AI-World 控制面板（双击本文件）
REM   只监听 127.0.0.1:8787，浏览器打开 http://127.0.0.1:8787/
REM   关掉这个窗口 = 关面板，并顺手停掉面板拉起的服务器和 ai
REM ============================================================
cd /d "%~dp0"
set "NODE=%~dp0运行时\node.exe"
if not exist "%NODE%" set "NODE=node"
"%NODE%" --version >nul 2>nul
if errorlevel 1 (
  echo [X] 找不到 Node：把 node.exe 放回 运行时\ 目录，或装 Node.js 后加进 PATH
  pause
  exit /b 1
)
echo 正在启动面板…浏览器会自动打开（打不开就手动访问 http://127.0.0.1:8787/）
"%NODE%" 源码\panel\server.js --port 8787
echo.
echo 面板已退出。
pause