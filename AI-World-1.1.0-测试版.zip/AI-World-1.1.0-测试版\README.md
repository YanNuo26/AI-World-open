# AI-World

Minecraft **1.21.1** 建造机器人：用 [mineflayer](https://github.com/PrismarineJS/mineflayer) 以玩家身份连进创造服，
听聊天指令搭建筑、录教学并复现、处理红石、召唤多个 ai；另带一个零依赖的**本地控制面板**和**夜间全量回归**。

> 术语：**AI** = 开发这个项目的编码助手；**ai** = 游戏里的机器人玩家（默认名 `world`）。

## 快速开始

```powershell
npm install                                                # 装依赖（node_modules 不入库）
powershell -ExecutionPolicy Bypass -File 脚本\start_server.ps1   # 起服务器（改配置要重启）
npm start                                                  # 起 ai（默认名 world）
npm run panel                                              # 控制面板 → http://127.0.0.1:8787/
```

Node 不在 PATH 时用绝对路径，例如 `D:\App存储\NodeJS\node.exe`。
重置世界：删掉 `服务器\存档\` 后重启服务器（测试污染严重，行为类测试前建议重置）。

## 打包成「绿色软件」（给不会用命令的人）

```powershell
powershell -ExecutionPolicy Bypass -File 脚本\打包.ps1
#   -NoRuntime 不塞 node.exe（包小 ~90MB，目标机得自己装 Node 18+）
#   -NoPrune   不裁剪依赖（minecraft-data 多占 ~420MB）
#   -Tag 测试版2 / -OutDir D:\发布   改包名后缀 / 输出目录
```

产物在 `发布\`：`AI-World-<版本>-<Tag>\`（解压即用）+ 同名 `.zip` + `发布说明.md`（大小 / SHA256 / 用法）。

包里自带 `运行时\node.exe`、裁剪过的 `node_modules`（去掉 bedrock 数据：449MB → 118MB）和两个入口
`启动面板.bat` / `启动AI.bat`，**目标机不用装 Node、不用 npm install**。
`发布\` 已在 `.gitignore` 里 —— 发版时把 zip 传到 Release，别塞进 git 历史。

## 目录

| 目录 | 作用 |
|---|---|
| `源码/` | 核心代码：`bot.js` 连接与指令路由、`build.js` 建造、`movement.js` 移动/朝向、`rcon.js`、`access.js` 权限 |
| `源码/panel/` | 本地控制面板（`server.js` + `api/` 接口 + `web/` 前端），只听 `127.0.0.1` |
| `测试/` | 单个用例 + `夜间回归.js`（自动起服、超时、重试、出报告） |
| `脚本/` | 一键启服务器 / 启面板 / 夜间回归 |
| `文档/` | `AI参考.md`（坑列表）、`架构与规划.md`、`文件结构.md`、`使用说明.md` |
| `开发日志/` | 每个开发用 AI 一份日志 + `总日志.md` |
| `蓝图/` `教学/` | 建筑蓝图与录制好的教学数据 |
| `服务器/` `日志/` | 运行产物，**不入库**（见 `.gitignore`） |

## 测试

```powershell
node 测试\test_access.js     # 纯离线用例，不需要服务器
node 测试\test_land.js       # 需要服务器在跑
node 测试\夜间回归.js --reset  # 夜间全量回归，产物在 日志\夜间回归\
```

## 文档入口

先读 [`AGENTS.md`](AGENTS.md)（协作约定），再读 [`文档/AI参考.md`](文档/AI参考.md)（踩过的坑）。
改放置 / 朝向 / 移动 / 传送 / 连接权限之前请务必看坑列表，很多问题不看代码根本发现不了。
