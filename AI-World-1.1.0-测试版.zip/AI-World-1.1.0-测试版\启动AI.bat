@echo off
chcp 65001 >nul
setlocal
REM ============================================================
REM   AI-World 的 ai（不经过面板，直接连服务器）
REM   参数接着写就行，例如：启动AI.bat --name bob --host 1.2.3.4 --port 25565
REM ============================================================
cd /d "%~dp0"
set "NODE=%~dp0运行时\node.exe"
if not exist "%NODE%" set "NODE=node"
"%NODE%" --version >nul 2>nul
if errorlevel 1 (
  echo [X] 找不到 Node：把 node.exe 放回 运行时\ 目录，或装 Node.js 后加进 PATH
  pause
  exit /b 1
)
"%NODE%" 源码\bot.js %*
echo.
echo ai 已退出（上面最后几行就是原因，也可以看 日志\ai_*.log）。
pause